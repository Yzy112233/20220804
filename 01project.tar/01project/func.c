#include "head.h"

/*******************************
函数功能：创建用户信息表
参数：sqlite *db  数据库句柄指针
返回值：成功返回0
       失败返回-1
********************************/
int create_usermsg(sqlite3 *db)
{
    char buf[500] = "create table if not exists usermsg (workno int PRIMARY KEY, \
    usertype int, username char, password char, age int,address char, \
    phone char, work char, data char, laver int, salary int)";
    char *errmsg = NULL;
    if (sqlite3_exec(db, buf, NULL, NULL, &errmsg) != SQLITE_OK)
    {
        fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
        return -1;
    }
    printf("usermsg table create successed\n");
    return 0;
}

/*******************************
函数功能：创建历史记录表
参数：sqlite *db  数据库句柄指针
返回值：成功返回0
       失败返回-1
********************************/
int create_history(sqlite3 *db)
{
    char buf[500] = "create table if not exists history (time char, name char, work char)";
    char *errmsg = NULL;
    if (sqlite3_exec(db, buf, NULL, NULL, &errmsg) != SQLITE_OK)
    {
        fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
        return -1;
    }

    printf("history table create successed\n");

    return 0;
}

/**************************************************
 
函数功能：获得当前时间函数
参数：char times[] 带回参数
返回值：无

**************************************************/
void get_local_tiam(char times[])
{
    time_t t = 0;
	struct tm *info = NULL;
    time(&t);                //获取秒数
	info = localtime(&t);    //获取日历格式
    sprintf(times, "%4d-%02d-%02d %02d:%02d:%02d", \
            info->tm_year+1900, info->tm_mon+1, info->tm_mday,\
            info->tm_hour, info->tm_min, info->tm_sec);
} 

/*******************************
函数功能：检验用户登录信息是否正确
参数：int newfd  套接字文件描述符
     sqlite *db  数据库句柄指针
     action_t *ac  通信信息结构体
返回值：成功返回0
       失败返回-1
********************************/
int user_login_on(int newfd, sqlite3 *db, action_t *ac)
{
    int i, row, column;
    char **result = NULL;
    char *errmsg = NULL;
    char sql[100] = "";
    if(ac->usertype == 0){
        //1.管理员用户登录
        strcpy(sql,"SELECT username, password FROM usermsg WHERE usertype=0");
    }else
        strcpy(sql,"SELECT * FROM usermsg WHERE usertype=1");
    //解析出用户名和密码是否正确   
    if (sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
    {
        fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
        return -1;
    }
    for (i = 0; i < (row + 1); i++)
    {
        if (strcmp(result[2 * i], ac->msg.usnm) == 0 && strcmp(result[2 * i + 1], ac->msg.pasw) == 0 && ac->usertype == 0)
        {
            strcpy(ac->buf,"亲爱的管理员，欢迎您登录员工管理系统");
            if(send(newfd,ac,sizeof(action_t),0) < 0){
                ERR_MSG("send");
                return -1;
            }
            return 0;
        }
        if (strcmp(result[11 * i+2], ac->msg.usnm) == 0 && strcmp(result[11 * i + 3], ac->msg.pasw) == 0 && ac->usertype == 1)
        {
            //保存普通用户登录的工号到通信结构体中并返回给客户端
            ac->msg.workno = atoi(result[11*i]);
            strcpy(ac->buf,"亲爱的员工，欢迎您登录员工管理系统");
            if(send(newfd,ac,sizeof(action_t),0) < 0){
                ERR_MSG("send");
                return -1;
            }
            return 0;
        }
    }
    strcpy(ac->buf,"账户或密码错误，请重新输入");
    if(send(newfd,ac,sizeof(action_t),0) < 0){
        ERR_MSG("send");
        return -1;
    }
    return 0;
}

/*******************************
函数功能：服务器接收数据recv函数
参数：int newfd;  套接字文件描述符
      struct sockaddr_in cin  客户端信息结构体
      action_t *ac  通信信息结构体
返回值：成功返回0
       失败返回-1
********************************/
int ser_recv(int newfd, action_t *ac, struct sockaddr_in cin)
{
    ssize_t ret;
    ret = recv(newfd, ac, sizeof(action_t), 0);
    if (ret < 0){
        ERR_MSG("recv");
        return -1;
    }
    else if (0 == ret){
        printf("newfd=%d [%s %d]客户端退出\n", newfd, inet_ntoa(cin.sin_addr), ntohs(cin.sin_port));
        return -1;
    }
    return 0;
}

/**************************************************
 
函数功能：服务器查询数据库函数并返回查询结果给客户端
参数：int sfd  套接字描述符
      sqlite3 *db   数据库句柄指针
      action_t *ac  通信信息结构体指针
      char sql[]   查询的数据库语句
返回值：无

**************************************************/
void query_return_to_client(int newfd,sqlite3 *db, action_t *ac,char sql[])
{
    int i, row, column;
    char **result = NULL;
    char *errmsg = NULL;
    if (sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
    {
        fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
    }
    for(i=0; i<(row+1); i++){
        bzero(ac->buf, sizeof(ac->buf));
        sprintf(ac->buf, "%10s%10s%10s%10s%10s%10s%10s%10s%10s%10s%10s", \
        result[column*i], result[column*i+1], result[column*i+2],\
        result[column*i+3],result[column*i+4],result[column*i+5],result[column*i+6],\
        result[column*i+7],result[column*i+8],result[column*i+9],result[column*i+10]);
        if (send(newfd, ac, sizeof(action_t), 0) < 0){
            ERR_MSG("send");
            return;
        }
    }
    sqlite3_free_table(result);
}

/*******************************
函数功能：服务器查询函数
参数：int newfd  套接字文件描述符
     sqlite *db  数据库句柄指针
     action_t *ac  接收的客户端通信信息结构体
返回值：成功返回0
       失败返回-1
********************************/
int server_Client_Query(int newfd,sqlite3 *db, action_t *ac)
{
    char sql[100] = "";
    //管理员模式查找
    if(ac->usertype == 0){
        //1.按人名查找
        if(ac->buf[0] == 'y'){
            sprintf(sql,"SELECT * FROM usermsg WHERE username='%s'",ac->msg.usnm);
            query_return_to_client(newfd,db, ac,sql);
        }else if(ac->buf[0]= 'n'){
            //2.查找全部 
            sprintf(sql,"SELECT * FROM usermsg");
            query_return_to_client(newfd,db, ac,sql);
        }
    }else if(ac->usertype == 1){   //普通用户查找
        sprintf(sql,"SELECT * FROM usermsg WHERE username='%s'",ac->msg.usnm);
        query_return_to_client(newfd,db, ac,sql);
    }
    
    //查询结束标志
    bzero(ac->buf, sizeof(ac->buf));
    strcpy(ac->buf,"over");
    if (send(newfd, ac, sizeof(action_t), 0) < 0){
        ERR_MSG("send");
    }
    return 0;
}

/**************************************************
 
函数功能：服务器修改数据库函数以及返回修改结果给客户端
参数： int sfd  套接字描述符
      sqlite3 *db   数据库句柄指针
      action_t *ac  通信信息结构体指针
      char sql[]   查询的数据库语句
返回值：无

**************************************************/
void change_return_to_client(int newfd,sqlite3 *db, action_t *ac,char sql[], char *errmsg)
{
    if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
        fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
        return;
    }
    ac->buf[0] = 'Y';
    if (send(newfd, ac, sizeof(action_t), 0) < 0){
        ERR_MSG("send");
        return;
    }
}

/**************************************************
 
函数功能：服务器修改函数并插入历史记录
参数：int sfd  套接字描述符
      sqlite3 *db   数据库句柄指针
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
int server_Client_Change(int newfd, sqlite3 *db, action_t *ac)
{
    int i, row, column;
    char **result = NULL;
    char *errmsg = NULL;
    char sql[128] = "";
    char times[128] = "";
    char work[128] = "";
    if(ac->usertype == 0){
        //判断工号是否存在
        sprintf(sql,"select * from usermsg where workno=%d", ac->msg.workno);
        if (sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
        {
            fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
            return -1;
        }
        if(row<1){
            ac->buf[0] = 'N';
            if (send(newfd, ac, sizeof(action_t), 0) < 0){
                ERR_MSG("send");
                return -1;
            }
            return -2;
        }
        //1.管理员模式修改选项
        switch (ac->buf[0])
        {
        case '1':           //修改姓名
            sprintf(sql,"update usermsg set username='%s' where workno=%d",ac->msg.usnm,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的姓名为%s",ac->msg.workno,ac->msg.usnm);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            
            break;
        case '2':           //修改年龄 
            sprintf(sql,"update usermsg set age=%d where workno=%d",ac->msg.age,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的年龄为%d",ac->msg.workno,ac->msg.age);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        case '3':            //修改家庭住址
            sprintf(sql,"update usermsg set address='%s' where workno=%d",ac->msg.address,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的家庭住址为%s",ac->msg.workno,ac->msg.address);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        case '4':            //修改电话
            sprintf(sql,"update usermsg set phone='%s' where workno=%d",ac->msg.phone,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的电话为%s",ac->msg.workno,ac->msg.phone);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        case '5':            //修改职位
            sprintf(sql,"update usermsg set work='%s' where workno=%d",ac->msg.posi,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的职位为%s",ac->msg.workno,ac->msg.posi);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;  
        case '6':            //修改工资
            sprintf(sql,"update usermsg set salary=%d where workno=%d",ac->msg.salary,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的工资为%d",ac->msg.workno,ac->msg.salary);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        case '7':            //修改入职年月
            sprintf(sql,"update usermsg set data='%s' where workno=%d",ac->msg.date,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的入职年月为%s",ac->msg.workno,ac->msg.date);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        case '8':            //修改评级
            sprintf(sql,"update usermsg set laver=%d where workno=%d",ac->msg.laver,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的评级为%d",ac->msg.workno,ac->msg.laver);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        case '9':            //修改密码
            sprintf(sql,"update usermsg set password='%s' where workno=%d",ac->msg.pasw,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的密码为%s",ac->msg.workno,ac->msg.pasw);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        default:
            break;
        }
    }else if(ac->usertype == 1){
        //2.普通用户模式
        switch (ac->buf[0])
        {
        case '1':           //修改家庭住址
            sprintf(sql,"update usermsg set address='%s' where workno=%d",ac->msg.address,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的家庭住址为%s",ac->msg.workno,ac->msg.address);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->msg.usnm,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }    
            break;
        case '2':           //电话
            sprintf(sql,"update usermsg set phone='%s' where workno=%d",ac->msg.phone,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的电话为%s",ac->msg.workno,ac->msg.phone);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->msg.usnm,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        case '3':           //密码
            sprintf(sql,"update usermsg set password='%s' where workno=%d",ac->msg.pasw,ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"修改工号%d的密码为%s",ac->msg.workno,ac->msg.pasw);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->msg.usnm,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return -1;
            }
            break;
        default:
            break;
        
        }
    }
    sqlite3_free_table(result);
}

/**************************************************
 
函数功能：服务器添加用户函数并插入历史记录
参数：int sfd  套接字描述符
      sqlite3 *db   数据库句柄指针
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void server_Client_Add(int newfd, sqlite3 *db, action_t *ac)
{
    char work[300] = "";
    char times[128] = "";
    char *errmsg = NULL;
    char sql[500] = "";
    sprintf(sql,"INSERT INTO usermsg VALUES (%d, %d, '%s', '%s', %d, '%s', '%s', '%s', '%s', %d, %d)",\
    ac->msg.workno,ac->msg.usertype,ac->msg.usnm,ac->msg.pasw,ac->msg.age,ac->msg.address,ac->msg.phone,ac->msg.posi,\
    ac->msg.date,ac->msg.laver,ac->msg.salary);
    change_return_to_client(newfd,db, ac,sql, errmsg);
    //插入历史记录
    bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
    get_local_tiam(times);              //调用函数获得当前时间
    sprintf(work,"管理员%s添加了%s用户",ac->buf+1,ac->msg.usnm);     //拼事件字符串
    sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
    if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
        fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
        return;
    }  
}

/**************************************************
 
函数功能：服务器删除用户函数并插入历史记录
参数：int sfd  套接字描述符
      sqlite3 *db   数据库句柄指针
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void server_Client_Del(int newfd, sqlite3 *db, action_t *ac)
{
    char work[300] = "";
    char times[128] = "";
    int i, row, column;
    char **result = NULL;
    char *errmsg = NULL;
    char sql[500] = "";
    strcpy(sql,"SELECT workno, username FROM usermsg");                                   //判断客户端提供的工号和用户名是否匹配
    if (sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
    {
        fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
        return;
    }
    for (i = 0; i < (row + 1); i++)
    {
        if ((atoi(result[2*i]) == ac->msg.workno) && (strcmp(result[2 * i + 1], ac->msg.usnm) == 0))
        {
            //若匹配则进行删除操作
            bzero(sql,sizeof(sql));
            sprintf(sql,"delete from usermsg where workno=%d",ac->msg.workno);
            change_return_to_client(newfd,db, ac,sql, errmsg);
            //插入历史记录
            bzero(sql,sizeof(sql));            //请空sql准备组新的插入历史记录语句
            get_local_tiam(times);              //调用函数获得当前时间
            sprintf(work,"管理员%s删除了工号%d用户名%s的用户",ac->buf+1,ac->msg.workno,ac->msg.usnm);     //拼事件字符串
            sprintf(sql,"insert into history values ('%s', '%s', '%s')",times,ac->buf+1,work);
            if(sqlite3_exec(db,sql,NULL,NULL,&errmsg)  != SQLITE_OK){
                fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
                return;
            }  
        }
    }
    ac->buf[0] = 'N';
    if (send(newfd, ac, sizeof(action_t), 0) < 0){
        ERR_MSG("send");
        return;
    }    
}

/**************************************************
 
函数功能：服务器查询历史记录
参数：int sfd  套接字描述符
      sqlite3 *db   数据库句柄指针
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void server_Client_His(int newfd, sqlite3 *db, action_t *ac)
{
    char sql[100] = "";
    sprintf(sql,"SELECT * FROM history");
    int i, row, column;
    char **result = NULL;
    char *errmsg = NULL;
    if (sqlite3_get_table(db, sql, &result, &row, &column, &errmsg) != SQLITE_OK)
    {
        fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__, __func__, errmsg);
    }
    for(i=0; i<(row+1); i++){
        bzero(ac->buf, sizeof(ac->buf));
        sprintf(ac->buf, "%s----%s-----%s", \
        result[column*i], result[column*i+1], result[column*i+2]);
        if (send(newfd, ac, sizeof(action_t), 0) < 0){
            ERR_MSG("send");
            return;
        }
    }

    //查询结束标志
    bzero(ac->buf, sizeof(ac->buf));
    strcpy(ac->buf,"over");
    if (send(newfd, ac, sizeof(action_t), 0) < 0){
        ERR_MSG("send");
    }

    sqlite3_free_table(result);
}

//线程回调函数
void *callback(void *arg)
{
    pthread_detach(pthread_self());
    sqlite3 *db = ((info_t *)arg)->pdb;
    int newfd = ((info_t *)arg)->newfd;
    struct sockaddr_in cin = ((info_t *)arg)->cin;
    action_t ac;
    ssize_t ret;
    while (1)
    {
        //接收用户请求
        ret = ser_recv(newfd, &ac, cin);
        printf("%d:cmd=%d:usertype=%d\n",__LINE__,ac.cmd,ac.usertype);
        if(ret) break;
        switch (ac.cmd)
        {
        case LOGIN:    //1.登录
            user_login_on(newfd, db, &ac);
            break;
        case QUERY:     //查询
            server_Client_Query(newfd,db, &ac);
            break;
        case CHANGE:     //修改
            server_Client_Change(newfd,db, &ac);
            break;
        case ADD_USER:     //添加
            server_Client_Add(newfd,db, &ac);
            break;
        case DEL_USER:     //删除
            server_Client_Del(newfd,db, &ac);
            break;
        case QUE_HIS:     //查历史记录
            server_Client_His(newfd, db, &ac);
            break;
        case EXIT:     //客户端退出
            close(newfd);
            pthread_exit(NULL);
            return NULL;
        default:
            break;
        }
             
    }
    close(newfd);
    pthread_exit(NULL);
}