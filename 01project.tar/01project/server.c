#include "head.h"

int main(int argc,const char * argv[])
{
    //1.打开数据库
    info_t vab;
    sqlite3 *db = NULL;
    int ret;
    pthread_t pid;
    struct sockaddr_in sin;
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = inet_addr(IP);
    sin.sin_port  = htons(PORT);

    if(sqlite3_open("./my.db", &db) != SQLITE_OK){
		fprintf(stderr, "__%d__错误信息:%s:%s:%s\n", __LINE__, __FILE__,__func__, sqlite3_errmsg(db));
		return -1;
	}
    //2.创建表
    ret = create_usermsg(db);
    if(ret == -1){
        return -1;
    }
    ret = create_history(db);
    if(ret == -1){
        return -1;
    }

    //3.初始化TCP服务器
    int sfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sfd < 0){
        ERR_MSG("socket");
        return -1;
    }

    int reuse = 1;
	if(setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) < 0){
		ERR_MSG("getsockopt");
		return -1;
	}

    if(bind(sfd, (struct sockaddr *)&sin, sizeof(sin)) < 0){
        ERR_MSG("bind");
        return -1;
    }

    if(listen(sfd, 10) < 0){
        ERR_MSG("listen");
        return -1;
    }

    socklen_t len = sizeof(vab.cin);
    vab.pdb = db;
    while(1){
        vab.newfd = accept(sfd, (struct sockaddr*)&vab.cin, &len);
        if(vab.newfd < 0){
            ERR_MSG("accept");
            break;
        }
        printf("newfd=%d [%s %d]客户端连接成功\n", vab.newfd, inet_ntoa(vab.cin.sin_addr), ntohs(vab.cin.sin_port));

        if(pthread_create(&pid,NULL,callback,(void *)&vab) != 0){
            ERR_MSG("pthread_create");
            break;;
        }
    }

    sqlite3_close(db);
    close(sfd);
    return 0;
}