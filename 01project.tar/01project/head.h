#ifndef __HEAD_H__
#define __HEAD_H__

#include <stdio.h>
#include <sqlite3.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#define BUFSIZE 20
#define PORT 8888
#define IP "192.168.250.100"
#define ERR_MSG(msg)                                               \
    {                                                              \
        fprintf(stderr, "%s:%s:%d", __FILE__, __func__, __LINE__); \
        perror(msg);                                               \
    }
//服务器框架文件和功能文件信息传递结构体
typedef struct 
{
    struct sockaddr_in cin;
    int newfd;
    sqlite3 *pdb;
} info_t;

//员工信息结构体
typedef struct 
{
    int workno;       //工号
    int usertype;     //用户类型
    char usnm[BUFSIZE];    //用户名
    char pasw[BUFSIZE];    //用户密码
    int age;          //年龄
    char address[BUFSIZE]; //地址
    char phone[BUFSIZE];   //电话号码
    char posi[BUFSIZE];    //工作岗位
    char date[BUFSIZE];    //入职时间
    int laver;        //职级 1~5
    int salary;       //薪资
} wmsg_t;

//客户端与服务器通信结构体
typedef struct 
{
    int usertype; //用户类型   0 管理员用户  1 普通用户
    int cmd;      //客户指令码
    char buf[128]; //通信消息
    wmsg_t msg;   //员工信息结构体
} action_t;


//客户端指令码

#define LOGIN     0        //登录
#define QUERY     1        //查询
#define CHANGE    2        //修改        1：姓名2：年龄3：家庭住址4：电话 5：职位  6：工资 7：入职年月   8：评级 9：密码  10：退出
#define ADD_USER  3     //添加用户
#define DEL_USER  4     //删除用户
#define QUE_HIS   5     //查询历史
#define EXIT     6        //客户端退出重新选择

//函数声明

int create_usermsg(sqlite3 *db);
int create_history(sqlite3 *db);
void *callback(void *);
int client_recv(int sfd, action_t *ac);

//客户端接口声明
void user_choose(int);  //选择管理员和普通用户界面
void admin_user_login(int , action_t *);  //登录
void admin_select(int, action_t*); //管理员选择，增删改查选择界面
void admin_user_query(int sfd, action_t *ac);     //查询函数
void user_select(int sfd, action_t *ac);   //普通用户选择界面
void admin_query_Frame(int sfd, action_t *ac);   //客户端查找
void admin_change_Frame(int sfd,action_t *ac);
void admin_user_change(int sfd, action_t *ac);    //修改函数
void admin_user_change_sand(int sfd, action_t *ac);
void normal_user_change(int sfd,action_t *ac);    //普通用户修改函数
void admin_Add_User_Frame(int sfd,action_t *ac);  //管理员添加用户函数
void admin_Del_User_Frame(int sfd,action_t *ac);  //管理员删除用户函数
void admin_Que_His_Frame(int sfd,action_t *ac);   //查询历史记录

#endif