#include "head.h"

/**************************************************
函数功能：与服务器交互函数
参数：int sfd;   套接字文件描述符
      action_t *ac  交互信息
返回值：成功返回0
        失败返回-1
***************************************************/
int client_recv(int sfd, action_t *ac)
{
    int ret;
    memset(ac,0,sizeof(action_t));
    ret = recv(sfd, ac, sizeof(action_t), 0);
    if (ret < 0)
    {
        ERR_MSG("recv");
        return -1;
    }
    else if (0 == ret)
    {
        printf("服务器退出\n");
        return -1;
    }
    return 0;
}

/**************************************************
函数功能：显示用户登录界面框架
参数：int sfd;   套接字文件描述符
返回值：无
***************************************************/
void user_choose(int sfd)
{
    action_t ac;
    char choose;
    while (1)
    {
        printf("*****************************************\n");
        printf("*************1.管理员模式  ***************\n");
        printf("*************2.普通用户模式***************\n");
        printf("*************3.退       出***************\n");
        printf("*****************************************\n");
        printf("请输入您的选择(数字)>>>");
        scanf("%c", &choose);
        while (getchar() != 10);
        switch (choose)
        {
        case '1':
            // 1.管理员模式
            ac.usertype = 0;
            admin_user_login(sfd, &ac);
            client_recv(sfd,&ac);
            printf("%s\n",ac.buf);
            if(!strcmp(ac.buf,"亲爱的管理员，欢迎您登录员工管理系统")){
                printf("%s\n",ac.msg.usnm);
                admin_select(sfd, &ac);
            }
            break;
        case '2':
            //2.普通用户模式
            ac.usertype = 1;
            admin_user_login(sfd, &ac);
            client_recv(sfd,&ac);
            printf("%s\n",ac.buf);
            if(!strcmp(ac.buf,"亲爱的员工，欢迎您登录员工管理系统")){
                user_select(sfd, &ac);
            }
            break;
        case '3':
            ac.cmd = EXIT;
            if(send(sfd,&ac,sizeof(action_t),0) < 0){
                ERR_MSG("send");
            }
            return;
        default:
            printf("输入错误请重新输入>>>\n");
            break;
        }
    }
}

/*******************************
函数功能：客户端登陆函数
参数：int sfd;   套接字文件描述符
     action_t *ac  通信信息结构体指针
返回值：无
********************************/
void admin_user_login(int sfd, action_t *ac)
{
    printf("------------admin_or_user_login------------\n");
    ac->cmd = LOGIN;             //填充登录指令码
    printf("请输入用户名>>>");
    fgets(ac->msg.usnm, BUFSIZE, stdin);
    ac->msg.usnm[strlen(ac->msg.usnm) - 1] = 0;
    printf("请输入密码>>>");
    fgets(ac->msg.pasw, BUFSIZE, stdin);
    ac->msg.pasw[strlen(ac->msg.pasw) - 1] = 0;
    if(send(sfd,ac,sizeof(action_t),0) < 0){
        ERR_MSG("send");
    }
}

/*******************************
函数功能：管理员操作主界面
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无
********************************/
void admin_select(int sfd, action_t *ac)
{
    char choose;
    while (1)
        {
            printf("------------------------------------------------------------------\n");
            printf("--1.查询  2.修改   3.添加员工   4.删除员工   5.查询历史记录   6.退出--\n");
            printf("------------------------------------------------------------------\n");
            printf("请输入您的选择(数字)>>>");
            scanf("%c", &choose);
            while (getchar() != 10);
            switch (choose)
            {
            case '1':
                ac->cmd = QUERY;
                ac->usertype = 0;
                admin_query_Frame(sfd,ac);
                break;
            case '2':
                ac->cmd = CHANGE;
                ac->usertype = 0;
                admin_change_Frame(sfd,ac);
                break;
            case '3':
                ac->cmd = ADD_USER;
                ac->usertype = 0;
                admin_Add_User_Frame(sfd,ac);
                break;
            case '4':
                ac->cmd = DEL_USER;
                ac->usertype = 1;
                admin_Del_User_Frame(sfd,ac);
                break;
            case '5':
                ac->cmd = QUE_HIS;
                ac->usertype = 1;
                admin_Que_His_Frame(sfd,ac);
                break;
            case '6':
                return;
            }

        }
}

/**************************************************
 
函数功能：管理员查询操作界面
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void admin_query_Frame(int sfd, action_t *ac)
{
    char choose;
    while(1){
        printf("----------do_admid_query----------\n");
        printf("************************************************\n");
        printf("****1.按人名查找    2.查找所有     3.退出*********\n");
        printf("************************************************\n");
        printf("请输入您的选择(数字)>>>");
        scanf("%c", &choose);
        while (getchar() != 10);
        switch (choose)
        {
        case '1':
            ac->buf[0] = 'y';  //表示按人名查找
            admin_user_query(sfd, ac);
            break;
        case '2':
            ac->buf[0] = 'n';  //查找全部
            admin_user_query(sfd, ac);
            break;
        case '3':

            return;
        default:
            break;
        }
    }                
}

/**************************************************
 
函数功能：管理员修改操作界面
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void admin_change_Frame(int sfd,action_t *ac)
{
    char choose;
    while(1){
        printf("-------------------do_admid_change--------------\n");
        printf("请输入您需要修改员工的工号>>>");
        scanf("%d",&ac->msg.workno);
        while (getchar() != 10);
        printf("**************请输入需要修改的选项*******************\n");
        printf("****1.姓名    2.年龄     3.家庭住址   4.电话*********\n");
        printf("****5.职位    6.工资     7.入职年月   8.评级*********\n");
        printf("****9.密码    10.退出                      *********\n");
        printf("***************************************************\n");
        printf("请输入您的选择(数字)>>>");
        scanf("%c", &choose);
        while (getchar() != 10);
        switch (choose)
        {
        case '1':           //修改姓名
            sprintf(ac->buf,"1%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的姓名>>>");
            fgets(ac->msg.usnm,BUFSIZE,stdin);
            ac->msg.usnm[strlen(ac->msg.usnm)-1]=0;
            admin_user_change_sand(sfd, ac);
            break;
        case '2':           //修改年龄 
            sprintf(ac->buf,"2%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的年龄>>>");
            scanf("%d",&ac->msg.age);
            while (getchar() != 10);
            admin_user_change_sand(sfd, ac);
            break;
        case '3':            //修改家庭住址
            sprintf(ac->buf,"3%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的家庭住址>>>");
            fgets(ac->msg.address,BUFSIZE,stdin);
            ac->msg.address[strlen(ac->msg.address)-1]=0;
            admin_user_change_sand(sfd, ac);
            break;
        case '4':            //修改电话
            sprintf(ac->buf,"4%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的电话>>>");
            fgets(ac->msg.phone,BUFSIZE,stdin);
            ac->msg.phone[strlen(ac->msg.phone)-1]=0;
            admin_user_change_sand(sfd, ac);
            break;
        case '5':            //修改职位
            sprintf(ac->buf,"5%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的职位>>>");
            fgets(ac->msg.posi,BUFSIZE,stdin);
            ac->msg.posi[strlen(ac->msg.posi)-1]=0;
            admin_user_change_sand(sfd, ac);
            break;  
        case '6':            //修改工资
            sprintf(ac->buf,"6%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的工资>>>");
            scanf("%d",&ac->msg.salary);
            while (getchar() != 10);
            admin_user_change_sand(sfd, ac);
            break;
        case '7':            //修改入职年月
            sprintf(ac->buf,"7%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的入职年月>>>");
            fgets(ac->msg.date,BUFSIZE,stdin);
            ac->msg.date[strlen(ac->msg.date)-1]=0;
            admin_user_change_sand(sfd, ac);
            break;
        case '8':            //修改评级
            sprintf(ac->buf,"8%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的评级>>>");
            scanf("%d",&ac->msg.laver);
            while (getchar() != 10);
            admin_user_change_sand(sfd, ac);
            break;
        case '9':            //修改密码
            sprintf(ac->buf,"9%s",ac->msg.usnm);        //保存管理员的名字到buf中
            printf("请输入新的密码>>>");
            fgets(ac->msg.pasw,BUFSIZE,stdin);
            ac->msg.pasw[strlen(ac->msg.pasw)-1]=0;
            admin_user_change_sand(sfd, ac);
            break;
        case '0':           //退出 
            return;
        default:
        printf("输入错误请重新输入\n");
            break;
        }
    }
}

/**************************************************
 
函数功能：管理员添加用户操作界面
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void admin_Add_User_Frame(int sfd,action_t *ac)
{
    char choose;
    printf("-------------------do_admin_adduser-------------------\n");
    printf("********************热烈欢迎新员工*********************\n");
    while(1){
        strcpy(ac->buf+1,ac->msg.usnm);
        printf("请输入工号:");
        scanf("%d",&ac->msg.workno);
        while(getchar() != 10);
        printf("您输入的工号是:%d\n",ac->msg.workno);
        printf("工号信息一旦录入无法更改，请确认您所输入的是否正确！(Y/N)  ");
        scanf("%c",&choose);
        while(getchar() != 10);
        if(choose =='n' || choose == 'N'){
            continue;;
        }
        printf("请输入用户名:");
        fgets(ac->msg.usnm,BUFSIZE,stdin);
        ac->msg.usnm[strlen(ac->msg.usnm)-1]=0;
        printf("请输入密码:");
        fgets(ac->msg.pasw,BUFSIZE,stdin);
        ac->msg.pasw[strlen(ac->msg.pasw)-1]=0;
        printf("请输入年龄:");
        scanf("%d",&ac->msg.age);
        while(getchar() != 10);
        printf("请输入电话:");
        fgets(ac->msg.phone,BUFSIZE,stdin);
        ac->msg.phone[strlen(ac->msg.phone)-1]=0;
        printf("请输入家庭住址:");
        fgets(ac->msg.address,BUFSIZE,stdin);
        ac->msg.address[strlen(ac->msg.address)-1]=0;
        printf("请输入职位:");
        fgets(ac->msg.posi,BUFSIZE,stdin);
        ac->msg.posi[strlen(ac->msg.posi)-1]=0;
        printf("请输入入职年月(格式: 0000.00.00):");
        fgets(ac->msg.date,BUFSIZE,stdin);
        ac->msg.date[strlen(ac->msg.date)-1]=0;
        printf("请输入评级(1~5,5为最高,新员工为 1):");
        scanf("%d",&ac->msg.laver);
        while(getchar() != 10);
        printf("请输入工资:");
        scanf("%d",&ac->msg.salary);
        while(getchar() != 10);
        printf("是否设为管理员:(Y/N)");
        scanf("%c",&choose);
        while(getchar() != 10);
        if(choose == 'n' || choose == 'N'){
            ac->msg.usertype = 1;
        }else{
            ac->msg.usertype = 0;
        }
        admin_user_change_sand(sfd, ac);
        printf("是否继续添加员工:(Y/N) ");
        scanf("%c",&choose);
        while(getchar() != 10);
        if(choose == 'n' || choose == 'N'){
            break;
        }
    }
}

/**************************************************
 
函数功能：管理员删除用户操作界面
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void admin_Del_User_Frame(int sfd,action_t *ac)
{
    printf("-------------------do_admin_deluser-------------------\n");
    strcpy(ac->buf+1,ac->msg.usnm);             //保存管理员的名字到buf中
    printf("请输入要删除的用户工号:");
    scanf("%d",&ac->msg.workno);
    while(getchar() != 10);
    printf("请输入要删除的用户名:");
    fgets(ac->msg.usnm,BUFSIZE,stdin);
    ac->msg.usnm[strlen(ac->msg.usnm)-1]=0;
    if(send(sfd,ac,sizeof(action_t),0) < 0){
        ERR_MSG("send");
    }
    client_recv(sfd,ac);
    if(ac->buf[0] == 'Y'){
        printf("数据库修改完毕，操作结束\n");
    }else{
        printf("输入的用户工号和用户名不匹配，请确认！\n");
    }
}

/**************************************************
 
函数功能：管理员查询历史记录
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void admin_Que_His_Frame(int sfd,action_t *ac)
{
    printf("-------------------do_admin_history-------------------\n"); 
    if(send(sfd,ac,sizeof(action_t),0) < 0){
        ERR_MSG("send");
    }
    while(ac->buf[0] != 'o'){
        client_recv(sfd, ac);
        printf("%s\n",ac->buf);
    }
}

/**************************************************
 
函数功能：发送修改通信结构体给服务器并反馈结果
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void admin_user_change_sand(int sfd, action_t *ac)
{
    if(send(sfd,ac,sizeof(action_t),0) < 0){
        ERR_MSG("send");
    }
    client_recv(sfd,ac);
    if(ac->buf[0] == 'N'){
        printf("工号不存在请确认！\n");
    }else{
        printf("数据库修改完毕，操作结束\n");
    }
}
    
/***************************************************
 
函数功能：普通用户操作主界面
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

****************************************************/
void user_select(int sfd, action_t *ac)
{
    char choose;
    while (1)
        {
            printf("---------------------------\n");
            printf("--1.查询  2.修改    3.退出--\n");
            printf("---------------------------\n");
            printf("请输入您的选择(数字)>>>");
            scanf("%c", &choose);
            while (getchar() != 10);
            switch (choose)
            {
            case '1':
                ac->cmd = QUERY;
                ac->usertype = 1;
                ac->buf[0] = 'u';
                admin_user_query(sfd, ac);
                break;
            case '2':
                ac->cmd = CHANGE;
                ac->usertype = 1;
                normal_user_change( sfd,ac);
                break;
            case '3':
                return;
            default:
                break;
            }
            
        }
}

/***************************************************
 
函数功能：普通用户和管理员查询功能函数
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

***************************************************/
void admin_user_query(int sfd, action_t *ac)
{
    if(ac->buf[0] == 'y'){        //根据用户名查询
        printf("请输入你需要查找的用户名>>>");
        fgets(ac->msg.usnm,BUFSIZE,stdin);
        ac->msg.usnm[strlen(ac->msg.usnm)-1]=0;
        if(send(sfd,ac,sizeof(action_t),0) < 0){
            ERR_MSG("send");
        }
        while(ac->buf[0] != 'o'){
            client_recv(sfd, ac);
            printf("=========================================================================================\n");
            printf("%s\n",ac->buf);
        }    
    }else if(ac->buf[0] == 'n'){     //查询所有
        if(send(sfd,ac,sizeof(action_t),0) < 0){
            ERR_MSG("send");
        }
        while(ac->buf[0] != 'o'){
            client_recv(sfd, ac);
            printf("=========================================================================================\n");
            printf("%s\n",ac->buf);
        }
    }else if(ac->buf[0] == 'u'){   //普通用户查询
        if(send(sfd,ac,sizeof(action_t),0) < 0){
            ERR_MSG("send");
        }
        while(ac->buf[0] != 'o'){
            client_recv(sfd, ac);
            printf("=========================================================================================\n");
            printf("%s\n",ac->buf);
        }
    }
    
}

/**************************************************
 
函数功能：普通用户修改操作界面
参数：int sfd  套接字描述符
      action_t *ac  通信信息结构体指针
返回值：无

**************************************************/
void normal_user_change(int sfd,action_t *ac)
{
    char choose;
    while (1)
        {
            printf("********************do_user_change********************\n");
            printf("-------请输入要修改的选项(其他信息请联系管理员)----------\n");
            printf("------------1.家庭住址  2.电话   3.密码   4.退出--------\n");
            printf("------------------------------------------------------\n");
            printf("请输入您的选择(数字)>>>");
            scanf("%c", &choose);
            while (getchar() != 10);
            switch (choose)
            {
            case '1':           //修改家庭住址
                ac->buf[0] = '1';
                printf("请输入新的家庭住址>>>");
                fgets(ac->msg.address,BUFSIZE,stdin);
                ac->msg.address[strlen(ac->msg.address)-1]=0;
                admin_user_change_sand(sfd, ac);
                break;
            case '2':           //电话
                ac->buf[0] = '2';
                printf("请输入新的电话>>>");
                fgets(ac->msg.phone,BUFSIZE,stdin);
                ac->msg.phone[strlen(ac->msg.phone)-1]=0;
                admin_user_change_sand(sfd, ac);
                break;
            case '3':           //密码
                ac->buf[0] = '3';
                printf("请输入新的密码>>>");
                fgets(ac->msg.pasw,BUFSIZE,stdin);
                ac->msg.pasw[strlen(ac->msg.pasw)-1]=0;
                admin_user_change_sand(sfd, ac);
                break;
            case '4':
                return;
            default:
                break;
            }
        }
}